    const hoc = (props) => props.children

export default hoc;