import React from 'react';

const result = (props) => (
    <div className={'Answer'}>{props.Ans}</div>
)

export default result;